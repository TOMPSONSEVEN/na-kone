type RequestLike = {
  method?: string;
  body?: unknown;
  headers?: Record<string, string | string[] | undefined>;
};

type ResponseLike = {
  status: (code: number) => ResponseLike;
  json: (body: unknown) => void;
};

type LeadBody = {
  name?: unknown;
  phone?: unknown;
  website?: unknown;
};

function escapeHtml(value: string) {
  return value.replace(/[&<>"']/g, (char) => {
    const entities: Record<string, string> = {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#039;",
    };
    return entities[char];
  });
}

function getBody(req: RequestLike): LeadBody {
  if (typeof req.body === "string") {
    try {
      return JSON.parse(req.body) as LeadBody;
    } catch {
      return {};
    }
  }

  return (req.body || {}) as LeadBody;
}

function formatMessage(name: string, phone: string) {
  const time = new Date().toLocaleString("ru-RU", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

  return [
    "🟢 <b>Новая заявка с сайта «На коне»</b>",
    "",
    `👤 <b>Имя:</b> ${escapeHtml(name)}`,
    `📞 <b>Телефон:</b> ${escapeHtml(phone)}`,
    `🕒 <b>Время:</b> ${time}`,
  ].join("\n");
}

/** Vercel serverless endpoint. Telegram credentials exist only in Vercel env vars. */
export default async function handler(req: RequestLike, res: ResponseLike) {
  if (req.method !== "POST") {
    return res.status(405).json({ ok: false, error: "Method not allowed" });
  }

  const headers = req.headers || {};
  const contentType = headers["content-type"];
  if (contentType && !String(contentType).includes("application/json")) {
    return res.status(415).json({ ok: false, error: "JSON is required" });
  }

  const configuredOrigins = (process.env.ALLOWED_ORIGIN || "")
    .split(",")
    .map((origin) => origin.trim().replace(/\/$/, ""))
    .filter(Boolean);
  const requestOriginValue = headers.origin;
  const requestOrigin = Array.isArray(requestOriginValue)
    ? requestOriginValue[0]
    : requestOriginValue;
  const vercelOrigin = process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : "";
  const productionOrigin = process.env.VERCEL_PROJECT_PRODUCTION_URL
    ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}`
    : "";
  const allowedOrigins = new Set([...configuredOrigins, vercelOrigin, productionOrigin].filter(Boolean));

  if (requestOrigin && allowedOrigins.size > 0 && !allowedOrigins.has(requestOrigin.replace(/\/$/, ""))) {
    return res.status(403).json({ ok: false, error: "Origin not allowed" });
  }

  const body = getBody(req);
  // Honeypot: normal visitors never fill this hidden field.
  if (typeof body.website === "string" && body.website.trim()) {
    return res.status(200).json({ ok: true });
  }

  const name = typeof body.name === "string" ? body.name.trim() : "";
  const phone = typeof body.phone === "string" ? body.phone.trim() : "";
  const phoneDigits = phone.replace(/\D/g, "");

  if (
    name.length < 2 ||
    name.length > 80 ||
    phone.length < 8 ||
    phone.length > 32 ||
    phoneDigits.length !== 11 ||
    phoneDigits[0] !== "7"
  ) {
    return res.status(400).json({ ok: false, error: "Invalid form data" });
  }

  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;
  if (!token || !chatId) {
    console.error("Missing TELEGRAM_BOT_TOKEN or TELEGRAM_CHAT_ID environment variable");
    return res.status(500).json({ ok: false, error: "Telegram is not configured" });
  }

  try {
    const telegramResponse = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text: formatMessage(name, phone),
        parse_mode: "HTML",
        disable_web_page_preview: true,
      }),
    });

    const telegramData = (await telegramResponse.json()) as { ok?: boolean; description?: string };
    if (!telegramResponse.ok || !telegramData.ok) {
      console.error("Telegram API error:", telegramData.description || telegramResponse.status);
      return res.status(502).json({ ok: false, error: "Telegram delivery failed" });
    }

    return res.status(200).json({ ok: true });
  } catch (error) {
    console.error("Telegram request failed:", error);
    return res.status(502).json({ ok: false, error: "Telegram delivery failed" });
  }
}
